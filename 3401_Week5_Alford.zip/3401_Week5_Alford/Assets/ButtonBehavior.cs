﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonBehavior : MonoBehaviour
{
    public AudioSource buttonAudioSource;
    public void OnButtonClicked ()
    {
        Debug.Log("button clicked!");
        {
            if (buttonAudioSource.isPlaying)
            {
                buttonAudioSource.Stop();
            }
        }
    }

}
